module.exports = require('./contracts.json')
